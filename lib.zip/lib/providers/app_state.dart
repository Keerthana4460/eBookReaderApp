import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/book.dart';
import '../models/user.dart';

class AppState extends ChangeNotifier {
  bool _isDarkMode = false;
  String _currentLanguage = 'en';
  User? _currentUser;
  List<Book> _books = [];
  List<Book> _filteredBooks = [];
  String _searchQuery = '';

  bool get isDarkMode => _isDarkMode;
  String get currentLanguage => _currentLanguage;
  User? get currentUser => _currentUser;
  List<Book> get books => _books;
  List<Book> get filteredBooks =>
      _searchQuery.isEmpty ? _books : _filteredBooks;
  List<Book> get favoriteBooks =>
      _books.where((book) => book.isFavorite).toList();

  AppState() {
    _loadPreferences();
    _loadBooks();
    _loadUser();
  }

  Future<void> _loadPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    _isDarkMode = prefs.getBool('isDarkMode') ?? false;
    _currentLanguage = prefs.getString('language') ?? 'en';
    notifyListeners();
  }

  Future<void> _loadBooks() async {
    final prefs = await SharedPreferences.getInstance();
    final booksJson = prefs.getString('books');
    if (booksJson != null) {
      final List<dynamic> decoded = json.decode(booksJson);
      _books = decoded.map((json) => Book.fromJson(json)).toList();
      notifyListeners();
    } else {
      _initializeSampleBooks();
    }
  }

  Future<void> _loadUser() async {
    final prefs = await SharedPreferences.getInstance();
    final userJson = prefs.getString('user');
    if (userJson != null) {
      _currentUser = User.fromJson(json.decode(userJson));
      notifyListeners();
    }
  }

  void _initializeSampleBooks() {
    _books = [
      Book(
        id: '1',
        title: 'The Great Adventure',
        author: 'John Smith',
        description:
            'An epic journey through uncharted territories filled with mystery and wonder.',
        coverUrl: 'https://picsum.photos/seed/book1/400/600',
        category: 'Adventure',
        totalPages: 350,
        currentPage: 45,
      ),
      Book(
        id: '2',
        title: 'Digital Dreams',
        author: 'Sarah Johnson',
        description:
            'A thought-provoking exploration of technology and human consciousness.',
        coverUrl: 'https://picsum.photos/seed/book2/400/600',
        category: 'Sci-Fi',
        totalPages: 420,
        currentPage: 120,
      ),
      Book(
        id: '3',
        title: 'Mystery Manor',
        author: 'Robert Brown',
        description:
            'A thrilling detective story set in an old Victorian mansion.',
        coverUrl: 'https://picsum.photos/seed/book3/400/600',
        category: 'Mystery',
        totalPages: 280,
        currentPage: 0,
      ),
      Book(
        id: '4',
        title: 'Love in Paris',
        author: 'Emma Davis',
        description:
            'A romantic tale of two souls finding each other in the City of Light.',
        coverUrl: 'https://picsum.photos/seed/book4/400/600',
        category: 'Romance',
        totalPages: 310,
        currentPage: 310,
        isFavorite: true,
      ),
      Book(
        id: '5',
        title: 'The Last Kingdom',
        author: 'Michael Wilson',
        description:
            'An epic fantasy saga of kingdoms, magic, and legendary heroes.',
        coverUrl: 'https://picsum.photos/seed/book5/400/600',
        category: 'Fantasy',
        totalPages: 550,
        currentPage: 200,
        isFavorite: true,
      ),
    ];
    _saveBooks();
  }

  Future<void> _saveBooks() async {
    final prefs = await SharedPreferences.getInstance();
    final booksJson = json.encode(_books.map((b) => b.toJson()).toList());
    await prefs.setString('books', booksJson);
  }

  Future<void> _saveUser() async {
    if (_currentUser != null) {
      final prefs = await SharedPreferences.getInstance();
      final userJson = json.encode(_currentUser!.toJson());
      await prefs.setString('user', userJson);
    }
  }

  Future<void> toggleDarkMode() async {
    _isDarkMode = !_isDarkMode;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isDarkMode', _isDarkMode);
    notifyListeners();
  }

  Future<void> changeLanguage(String language) async {
    _currentLanguage = language;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('language', language);
    notifyListeners();
  }

  Future<void> login(String email, String password) async {
    // Simulate login
    _currentUser = User(
      id: '1',
      name: 'Book Lover',
      email: email,
    );
    await _saveUser();
    notifyListeners();
  }

  Future<void> signup(String name, String email, String password) async {
    // Simulate signup
    _currentUser = User(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: name,
      email: email,
    );
    await _saveUser();
    notifyListeners();
  }

  Future<void> updateUserPhoto(String photoUrl) async {
    if (_currentUser != null) {
      _currentUser = _currentUser!.copyWith(photoUrl: photoUrl);
      await _saveUser();
      notifyListeners();
    }
  }

  Future<void> updateUserProfile(String name, String email) async {
    if (_currentUser != null) {
      _currentUser = _currentUser!.copyWith(name: name, email: email);
      await _saveUser();
      notifyListeners();
    }
  }

  void logout() {
    _currentUser = null;
    notifyListeners();
  }

  void addBook(Book book) {
    _books.insert(0, book);
    _saveBooks();
    notifyListeners();
  }

  void updateBook(Book book) {
    final index = _books.indexWhere((b) => b.id == book.id);
    if (index != -1) {
      _books[index] = book;
      _saveBooks();
      notifyListeners();
    }
  }

  void deleteBook(String bookId) {
    _books.removeWhere((b) => b.id == bookId);
    _saveBooks();
    notifyListeners();
  }

  void toggleFavorite(String bookId) {
    final book = _books.firstWhere((b) => b.id == bookId);
    updateBook(book.copyWith(isFavorite: !book.isFavorite));
  }

  void updateReadingProgress(String bookId, int currentPage) {
    final book = _books.firstWhere((b) => b.id == bookId);
    updateBook(book.copyWith(currentPage: currentPage));
  }

  void addBookmark(String bookId, Bookmark bookmark) {
    final book = _books.firstWhere((b) => b.id == bookId);
    final updatedBookmarks = [...book.bookmarks, bookmark];
    updateBook(book.copyWith(bookmarks: updatedBookmarks));
  }

  void removeBookmark(String bookId, String bookmarkId) {
    final book = _books.firstWhere((b) => b.id == bookId);
    final updatedBookmarks =
        book.bookmarks.where((b) => b.id != bookmarkId).toList();
    updateBook(book.copyWith(bookmarks: updatedBookmarks));
  }

  void searchBooks(String query) {
    _searchQuery = query.toLowerCase();
    if (_searchQuery.isEmpty) {
      _filteredBooks = [];
    } else {
      _filteredBooks = _books
          .where((book) =>
              book.title.toLowerCase().contains(_searchQuery) ||
              book.author.toLowerCase().contains(_searchQuery) ||
              book.category.toLowerCase().contains(_searchQuery))
          .toList();
    }
    notifyListeners();
  }

  List<Book> getBooksByCategory(String category) {
    return _books.where((book) => book.category == category).toList();
  }

  List<String> getCategories() {
    return _books.map((book) => book.category).toSet().toList();
  }
}

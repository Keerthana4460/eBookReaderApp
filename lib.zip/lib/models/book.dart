class Book {
  final String id;
  final String title;
  final String author;
  final String description;
  final String coverUrl;
  final String category;
  final int totalPages;
  final List<Bookmark> bookmarks;
  int currentPage;
  bool isFavorite;
  DateTime addedDate;

  Book({
    required this.id,
    required this.title,
    required this.author,
    required this.description,
    required this.coverUrl,
    required this.category,
    required this.totalPages,
    this.currentPage = 0,
    this.isFavorite = false,
    List<Bookmark>? bookmarks,
    DateTime? addedDate,
  })  : bookmarks = bookmarks ?? [],
        addedDate = addedDate ?? DateTime.now();

  double get progress => totalPages > 0 ? currentPage / totalPages : 0;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'author': author,
        'description': description,
        'coverUrl': coverUrl,
        'category': category,
        'totalPages': totalPages,
        'currentPage': currentPage,
        'isFavorite': isFavorite,
        'bookmarks': bookmarks.map((b) => b.toJson()).toList(),
        'addedDate': addedDate.toIso8601String(),
      };

  factory Book.fromJson(Map<String, dynamic> json) => Book(
        id: json['id'],
        title: json['title'],
        author: json['author'],
        description: json['description'],
        coverUrl: json['coverUrl'],
        category: json['category'],
        totalPages: json['totalPages'],
        currentPage: json['currentPage'] ?? 0,
        isFavorite: json['isFavorite'] ?? false,
        bookmarks: (json['bookmarks'] as List?)
                ?.map((b) => Bookmark.fromJson(b))
                .toList() ??
            [],
        addedDate: DateTime.parse(json['addedDate']),
      );

  Book copyWith({
    String? id,
    String? title,
    String? author,
    String? description,
    String? coverUrl,
    String? category,
    int? totalPages,
    int? currentPage,
    bool? isFavorite,
    List<Bookmark>? bookmarks,
    DateTime? addedDate,
  }) {
    return Book(
      id: id ?? this.id,
      title: title ?? this.title,
      author: author ?? this.author,
      description: description ?? this.description,
      coverUrl: coverUrl ?? this.coverUrl,
      category: category ?? this.category,
      totalPages: totalPages ?? this.totalPages,
      currentPage: currentPage ?? this.currentPage,
      isFavorite: isFavorite ?? this.isFavorite,
      bookmarks: bookmarks ?? this.bookmarks,
      addedDate: addedDate ?? this.addedDate,
    );
  }
}

class Bookmark {
  final String id;
  final int page;
  final String note;
  final DateTime createdAt;

  Bookmark({
    required this.id,
    required this.page,
    required this.note,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toJson() => {
        'id': id,
        'page': page,
        'note': note,
        'createdAt': createdAt.toIso8601String(),
      };

  factory Bookmark.fromJson(Map<String, dynamic> json) => Bookmark(
        id: json['id'],
        page: json['page'],
        note: json['note'],
        createdAt: DateTime.parse(json['createdAt']),
      );
}

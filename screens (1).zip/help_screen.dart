import 'package:flutter/material.dart';
import 'package:animate_do/animate_do.dart';
import '../utils/app_localizations.dart';

class HelpScreen extends StatefulWidget {
  const HelpScreen({super.key});

  @override
  State<HelpScreen> createState() => _HelpScreenState();
}

class _HelpScreenState extends State<HelpScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(localizations.translate('help')),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Getting Started', icon: Icon(Icons.rocket_launch)),
            Tab(text: 'FAQ', icon: Icon(Icons.question_answer)),
            Tab(text: 'Contact', icon: Icon(Icons.contact_support)),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildGettingStarted(context),
          _buildFAQ(context),
          _buildContact(context, localizations),
        ],
      ),
    );
  }

  Widget _buildGettingStarted(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        FadeInDown(
          child: _buildTutorialCard(
            context,
            '1. Adding Books',
            'Tap the + button in the Explore tab to add a new book to your library. Fill in the book details and upload a cover image.',
            Icons.add_circle,
            Colors.blue,
          ),
        ),
        const SizedBox(height: 16),
        FadeInLeft(
          delay: const Duration(milliseconds: 200),
          child: _buildTutorialCard(
            context,
            '2. Reading Books',
            'Tap on any book to view its details. Use the "Start Reading" or "Continue" button to begin or resume reading.',
            Icons.menu_book,
            Colors.green,
          ),
        ),
        const SizedBox(height: 16),
        FadeInRight(
          delay: const Duration(milliseconds: 400),
          child: _buildTutorialCard(
            context,
            '3. Bookmarks',
            'Add bookmarks while reading to save your favorite passages or important pages. Access them anytime from the book details.',
            Icons.bookmark,
            Colors.orange,
          ),
        ),
        const SizedBox(height: 16),
        FadeInLeft(
          delay: const Duration(milliseconds: 600),
          child: _buildTutorialCard(
            context,
            '4. Favorites',
            'Mark books as favorites by tapping the heart icon. Access all your favorite books from the Home tab.',
            Icons.favorite,
            Colors.red,
          ),
        ),
        const SizedBox(height: 16),
        FadeInRight(
          delay: const Duration(milliseconds: 800),
          child: _buildTutorialCard(
            context,
            '5. Search & Explore',
            'Use the Search tab to find books quickly. Explore categories in the Explore tab to discover new books.',
            Icons.search,
            Colors.purple,
          ),
        ),
        const SizedBox(height: 16),
        FadeInUp(
          delay: const Duration(milliseconds: 1000),
          child: _buildTutorialCard(
            context,
            '6. Dark Mode & Settings',
            'Customize your reading experience in Settings. Toggle dark mode, change language, and adjust reading preferences.',
            Icons.settings,
            Colors.teal,
          ),
        ),
      ],
    );
  }

  Widget _buildTutorialCard(
    BuildContext context,
    String title,
    String description,
    IconData icon,
    Color color,
  ) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 28),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    description,
                    style: TextStyle(
                      color: Colors.grey[600],
                      height: 1.5,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFAQ(BuildContext context) {
    final faqs = [
      {
        'question': 'How do I add a book to my library?',
        'answer':
            'Navigate to the Explore tab and tap the + button. Fill in the book details including title, author, category, description, and total pages. You can also upload a cover image from your gallery.',
      },
      {
        'question': 'Can I read books offline?',
        'answer':
            'Yes! All books in your library are stored locally on your device, allowing you to read them anytime without an internet connection.',
      },
      {
        'question': 'How do I track my reading progress?',
        'answer':
            'Reading progress is automatically saved. You can manually update your current page in the book details screen by tapping "Update Progress".',
      },
      {
        'question': 'How do I add bookmarks?',
        'answer':
            'Open any book and tap the bookmark icon. Enter the page number and an optional note. Your bookmarks will be saved and accessible from the book details screen.',
      },
      {
        'question': 'How do I change the app language?',
        'answer':
            'Go to Settings and select your preferred language from English, Spanish, or French. The app will immediately update to your chosen language.',
      },
      {
        'question': 'Can I export my book list?',
        'answer':
            'Currently, all your books are stored locally. An export feature will be available in future updates.',
      },
      {
        'question': 'How do I delete a book?',
        'answer':
            'Long press on any book in your library to reveal delete option, or swipe left on the book card to delete it.',
      },
      {
        'question': 'Is my data synchronized across devices?',
        'answer':
            'Currently, data is stored locally on your device. Cloud sync functionality will be added in a future update.',
      },
    ];

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: faqs.length,
      itemBuilder: (context, index) {
        return FadeInUp(
          delay: Duration(milliseconds: index * 100),
          child: _buildFAQItem(
            context,
            faqs[index]['question']!,
            faqs[index]['answer']!,
          ),
        );
      },
    );
  }

  Widget _buildFAQItem(BuildContext context, String question, String answer) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          title: Text(
            question,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                answer,
                style: TextStyle(
                  color: Colors.grey[600],
                  height: 1.5,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContact(BuildContext context, AppLocalizations localizations) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        FadeInDown(
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Icon(
                    Icons.support_agent,
                    size: 64,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Need More Help?',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'We\'re here to help! Reach out to us through any of the following channels.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.grey[600]),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),
        FadeInLeft(
          delay: const Duration(milliseconds: 200),
          child: Card(
            child: ListTile(
              leading: const Icon(Icons.email, color: Colors.blue),
              title: const Text('Email Support'),
              subtitle: const Text('support@ebookreader.com'),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              onTap: () {},
            ),
          ),
        ),
        const SizedBox(height: 12),
        FadeInRight(
          delay: const Duration(milliseconds: 400),
          child: Card(
            child: ListTile(
              leading: const Icon(Icons.chat, color: Colors.green),
              title: const Text('Live Chat'),
              subtitle: const Text('Chat with our support team'),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              onTap: () {},
            ),
          ),
        ),
        const SizedBox(height: 12),
        FadeInLeft(
          delay: const Duration(milliseconds: 600),
          child: Card(
            child: ListTile(
              leading: const Icon(Icons.web, color: Colors.orange),
              title: const Text('Website'),
              subtitle: const Text('www.ebookreader.com'),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              onTap: () {},
            ),
          ),
        ),
        const SizedBox(height: 12),
        FadeInRight(
          delay: const Duration(milliseconds: 800),
          child: Card(
            child: ListTile(
              leading: const Icon(Icons.bug_report, color: Colors.red),
              title: const Text('Report a Bug'),
              subtitle: const Text('Help us improve the app'),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              onTap: () {},
            ),
          ),
        ),
        const SizedBox(height: 24),
        FadeInUp(
          delay: const Duration(milliseconds: 1000),
          child: Card(
            color: Theme.of(context).colorScheme.primaryContainer,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Icon(
                    Icons.schedule,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Support Hours',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Monday - Friday: 9AM - 6PM EST\nSaturday - Sunday: 10AM - 4PM EST',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.grey[700]),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:animate_do/animate_do.dart';
import '../providers/app_state.dart';
import '../utils/app_localizations.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context);
    final appState = context.watch<AppState>();

    return Scaffold(
      appBar: AppBar(
        title: Text(localizations.translate('settings')),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Appearance Section
          FadeInDown(
            child: _buildSectionHeader(context, 'Appearance'),
          ),
          FadeInLeft(
            delay: const Duration(milliseconds: 100),
            child: Card(
              child: SwitchListTile(
                secondary: Icon(
                  appState.isDarkMode ? Icons.dark_mode : Icons.light_mode,
                ),
                title: Text(localizations.translate('dark_mode')),
                subtitle: Text(
                  appState.isDarkMode ? 'Dark theme enabled' : 'Light theme enabled',
                ),
                value: appState.isDarkMode,
                onChanged: (_) => appState.toggleDarkMode(),
              ),
            ),
          ),
          const SizedBox(height: 24),

          // Language Section
          FadeInDown(
            delay: const Duration(milliseconds: 200),
            child: _buildSectionHeader(context, localizations.translate('language')),
          ),
          FadeInRight(
            delay: const Duration(milliseconds: 300),
            child: Card(
              child: Column(
                children: [
                  RadioListTile<String>(
                    secondary: const Text('🇺🇸', style: TextStyle(fontSize: 24)),
                    title: const Text('English'),
                    subtitle: const Text('English'),
                    value: 'en',
                    groupValue: appState.currentLanguage,
                    onChanged: (value) => appState.changeLanguage(value!),
                  ),
                  const Divider(height: 1),
                  RadioListTile<String>(
                    secondary: const Text('🇪🇸', style: TextStyle(fontSize: 24)),
                    title: const Text('Español'),
                    subtitle: const Text('Spanish'),
                    value: 'es',
                    groupValue: appState.currentLanguage,
                    onChanged: (value) => appState.changeLanguage(value!),
                  ),
                  const Divider(height: 1),
                  RadioListTile<String>(
                    secondary: const Text('🇫🇷', style: TextStyle(fontSize: 24)),
                    title: const Text('Français'),
                    subtitle: const Text('French'),
                    value: 'fr',
                    groupValue: appState.currentLanguage,
                    onChanged: (value) => appState.changeLanguage(value!),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),

          // Notifications Section
          FadeInDown(
            delay: const Duration(milliseconds: 400),
            child: _buildSectionHeader(context, localizations.translate('notifications')),
          ),
          FadeInLeft(
            delay: const Duration(milliseconds: 500),
            child: Card(
              child: Column(
                children: [
                  SwitchListTile(
                    secondary: const Icon(Icons.notifications),
                    title: const Text('Push Notifications'),
                    subtitle: const Text('Receive reading reminders'),
                    value: true,
                    onChanged: (value) {},
                  ),
                  const Divider(height: 1),
                  SwitchListTile(
                    secondary: const Icon(Icons.email),
                    title: const Text('Email Notifications'),
                    subtitle: const Text('Get updates via email'),
                    value: false,
                    onChanged: (value) {},
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),

          // Reading Preferences
          FadeInDown(
            delay: const Duration(milliseconds: 600),
            child: _buildSectionHeader(context, 'Reading Preferences'),
          ),
          FadeInRight(
            delay: const Duration(milliseconds: 700),
            child: Card(
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(Icons.text_fields),
                    title: const Text('Font Size'),
                    subtitle: const Text('Medium'),
                    trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                    onTap: () {},
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const Icon(Icons.format_line_spacing),
                    title: const Text('Line Spacing'),
                    subtitle: const Text('Normal'),
                    trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                    onTap: () {},
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const Icon(Icons.brightness_6),
                    title: const Text('Page Brightness'),
                    subtitle: const Text('Adjust reading brightness'),
                    trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                    onTap: () {},
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),

          // About Section
          FadeInDown(
            delay: const Duration(milliseconds: 800),
            child: _buildSectionHeader(context, localizations.translate('about')),
          ),
          FadeInLeft(
            delay: const Duration(milliseconds: 900),
            child: Card(
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(Icons.info),
                    title: Text(localizations.translate('about')),
                    trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                    onTap: () => _showAboutDialog(context),
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const Icon(Icons.description),
                    title: Text(localizations.translate('terms')),
                    trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                    onTap: () {},
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const Icon(Icons.privacy_tip),
                    title: Text(localizations.translate('privacy')),
                    trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                    onTap: () {},
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const Icon(Icons.code),
                    title: Text(localizations.translate('version')),
                    subtitle: const Text('1.0.0'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 8, bottom: 8),
      child: Text(
        title,
        style: Theme.of(context).textTheme.titleMedium?.copyWith(
          fontWeight: FontWeight.bold,
          color: Theme.of(context).colorScheme.primary,
        ),
      ),
    );
  }

  void _showAboutDialog(BuildContext context) {
    showAboutDialog(
      context: context,
      applicationName: 'eBook Reader',
      applicationVersion: '1.0.0',
      applicationIcon: Container(
        width: 60,
        height: 60,
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.primary,
          borderRadius: BorderRadius.circular(12),
        ),
        child: const Icon(Icons.menu_book_rounded, color: Colors.white, size: 32),
      ),
      children: [
        const Text(
          'A beautiful and intuitive e-reading experience with library management, bookmarks, and offline reading support.',
        ),
        const SizedBox(height: 16),
        const Text(
          'Developed with Flutter',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ],
    );
  }
}
